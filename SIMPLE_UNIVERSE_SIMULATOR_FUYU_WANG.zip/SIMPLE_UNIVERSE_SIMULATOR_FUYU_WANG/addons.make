ofxGui
ofxOpenCv
